package messages;

public class Login {
	//message
		public final static String HEADER = "Log in";
		
		//errors
		public final static String LOGIN_ERROR = "Incorrect username or password entered. Please try again.";
	}

