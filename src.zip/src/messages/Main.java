package messages;

public class Main {
	public final static String HEADER = "Welcome to Wikipedia";
}
