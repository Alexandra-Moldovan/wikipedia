package messages;

public class Start {
	public final static String HEADER = "Wikipedia";
	public final static String SUBHEADER = "The Free Encyclopedia";
}
