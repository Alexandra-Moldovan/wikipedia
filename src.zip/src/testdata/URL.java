package testdata;

public class URL {
	public final static String BASE_URL = "https://www.wikipedia.org/";
}
